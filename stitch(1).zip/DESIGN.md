# Design System Specification: The Executive Intelligence Interface

This document outlines the visual language and structural logic for a high-end labor law executive dashboard. This design system is built to move beyond "standard" dashboard aesthetics, favoring an editorial, high-fidelity experience that communicates authority, precision, and strategic depth.

---

## 1. Creative North Star: "The Digital Jurist"
The guiding philosophy of this system is **The Digital Jurist**. Much like a well-tailored suit or a high-end architectural space, the interface must feel bespoke, quiet, and intentional. We reject the "clutter" of traditional Business Intelligence. Instead, we use expansive white space, asymmetric layout anchors, and sophisticated tonal layering to guide the executive’s eye to what matters most. 

The goal is not just to display data, but to provide a "quiet room" for critical decision-making.

---

## 2. Color & Surface Logic

### The Palette
The core of the system is built on **Deep Navy (#1A2B48)** and **Clean Whites (#F8F9FA)**, providing a high-contrast, trustworthy foundation.

- **Primary (`#031632`)**: Used for the most critical brand anchors and deep-state navigation.
- **Primary Container (`#1A2B48`)**: The signature "Navy" for high-level KPI cards and active states.
- **Surface (`#F8F9FA`)**: The global canvas.
- **Semantic Accents**: 
  - **Error (`#BA1A1A`)**: Critical labor law violations or missed deadlines.
  - **Tertiary Fixed Dim (`#E5C18A`)**: Attention/Warning states that feel "golden" and premium rather than "cheap" yellow.

### The "No-Line" Rule
**Explicit Instruction:** Prohibit the use of 1px solid borders for sectioning or containment. 
Boundaries must be defined solely through background color shifts. For example, a `surface-container-low` section sitting on a `surface` background creates a clear but sophisticated division. Lines feel like "technical debt"; tonal shifts feel like "design."

### Surface Hierarchy & Nesting
Treat the UI as a series of stacked, physical layers.
1.  **Level 0 (Base):** `surface` (#F8F9FA) – The desk.
2.  **Level 1 (Sections):** `surface-container-low` (#F3F4F5) – Large content areas.
3.  **Level 2 (Cards):** `surface-container-lowest` (#FFFFFF) – The primary data units.
4.  **Level 3 (Popovers):** `surface-bright` (#F8F9FA) – Floating elements.

### The "Glass & Gradient" Rule
To elevate the "High-End BI" feel, use **Glassmorphism** for floating headers or filter bars. Apply `backdrop-blur: 12px` to a semi-transparent `surface-container-lowest` (80% opacity). For main Action Buttons, use a subtle linear gradient from `primary` to `primary_container` to add "soul" and dimension.

---

## 3. Typography: Editorial Authority

We use a dual-sans-serif approach to create an editorial hierarchy.

*   **Display & Headlines (Manrope):** Used for KPIs and Page Titles. Manrope’s geometric yet warm nature feels modern and proprietary.
*   **Body & Labels (Inter):** Used for analytical data and UI controls. Inter provides maximum legibility at small sizes in dense tables.

### Hierarchy Highlights
- **KPI Display (`display-lg`)**: 3.5rem / Manrope. Use `font-weight: 700` and `letter-spacing: -0.02em` for an authoritative, "Wall Street Journal" feel.
- **Section Headers (`headline-sm`)**: 1.5rem / Manrope. Use for card titles to provide a distinct break from the data.
- **Data Labels (`label-md`)**: 0.75rem / Inter. Use `on-surface-variant` color for metadata to reduce visual noise.

---

## 4. Elevation, Depth & The "Ghost Border"

### The Layering Principle
Depth is achieved by "stacking" surface tiers. Place a `surface-container-lowest` (pure white) card on a `surface-container-low` background. This creates a soft, natural lift that mimics fine paper.

### Ambient Shadows
Shadows must be extra-diffused. 
- **Standard Card:** `0px 4px 20px rgba(25, 28, 29, 0.04)`
- **Floating Menu:** `0px 12px 40px rgba(25, 28, 29, 0.08)`
The shadow color is a tinted version of the `on-surface` color, never pure black.

### The "Ghost Border" Fallback
If a border is required for accessibility (e.g., in a high-density table), use the **Ghost Border**: 
`outline-variant` token at **15% opacity**. High-contrast, 100% opaque borders are strictly forbidden.

---

## 5. Components

### Analytical Cards
- **Construction:** Use `surface-container-lowest` with a `lg` (0.5rem) corner radius.
- **Constraint:** No divider lines between card header and body. Use a `spacing-6` (1.3rem) vertical gap to define the split.
- **KPI Content:** Pair a `display-sm` value with a `label-md` trend indicator (using `error` or `positive` tokens).

### Filter Header
- **Style:** Use the **Glassmorphism** rule.
- **Layout:** Position as a "floating bar" at the top of the viewport with a `xl` (0.75rem) radius and a `surface-container-low` ghost border.

### Buttons
- **Primary:** Gradient fill (`primary` to `primary-container`), `md` (0.375rem) radius, white text.
- **Secondary:** Transparent background with a `ghost border` and `primary` text.
- **Tertiary:** No background or border. Use `primary` text with an icon.

### Analytical Tables
- **Row Separation:** Strictly forbidden to use horizontal lines. Use alternating row colors (`surface` and `surface-container-low`) or simply generous vertical spacing (`spacing-4`).
- **Typography:** Use `body-md` for row content, and `label-sm` (all caps, 0.05em tracking) for column headers.

### Specialized Labor Law Components
- **Compliance Status Chips:** Use a soft "pill" shape (`full` radius). Instead of high-saturation fills, use `error_container` with `on_error_container` text for a sophisticated, muted alert.
- **Timeline Progression:** Use a vertical "Thread" layout with `surface-dim` connectors and `primary` nodes.

---

## 6. Do’s and Don’ts

### Do
- **Do** use intentional asymmetry. Align a large KPI to the left and balance it with smaller trend data on the right.
- **Do** use the Spacing Scale religiously. Consistent gaps (`spacing-8` between cards) create the "luxury" feel.
- **Do** leverage "Negative Space" as a design element. If a screen feels crowded, remove a container, don't shrink the text.

### Don't
- **Don't** use pure black (#000000). Use `primary` or `on-surface`.
- **Don't** use standard 1px borders. If you feel you need a line, try a background color shift first.
- **Don't** use default chart colors. Map chart palettes to the system’s `primary`, `secondary_fixed`, and `tertiary_fixed_dim` tokens.
- **Don't** use shadows on every element. Only use shadows for elements that truly "float" (modals, dropdowns). Cards should rely on tonal shifts.